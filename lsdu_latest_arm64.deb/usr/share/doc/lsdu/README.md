# lsdu

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Rust](https://img.shields.io/badge/Made%20with-Rust-orange.svg)](https://www.rust-lang.org/)
[![Platform](https://img.shields.io/badge/Platform-Linux-blue.svg)](#)
[![Debian Package](https://img.shields.io/badge/Debian-.deb-red.svg)](#)

**lsdu = ls + du**

List directories and files with **recursive sizes**, **permissions**, **owner/group**, **timestamps**, **git status**, and **rich color output**.
It can also display results as a **tree**, as a **grid**, and provides an **interactive fuzzy picker with preview**.

---

## Features

- Recursive directory sizes (real content size)
- Perfectly aligned columns (dynamic widths)
- Sorting:
  - directories first, files next, hidden last
  - sort key: name/size/time/extension
  - reverse mode
- Git integration: show a simple status letter per entry
- Tree view
- Grid view (multi-column)
- Parallel size computation (fast on big directories)
- Filtering:
  - glob patterns (`--filter`)
  - size range (`--min-size`, `--max-size`)
  - only files / only dirs
- Interactive mode (fuzzy search + preview)
- Debian packaging ready (.deb) + man page

---

## Installation

### Debian/Ubuntu (.deb)
1. Download the `.deb` from GitHub Releases (recommended).
2. Install:
```bash
sudo dpkg -i lsdu_*.deb
sudo apt-get install -f
```

### From source (Rust / Cargo)
```bash
cargo build --release
sudo cp target/release/lsdu /usr/local/bin/
```

### Install with Cargo
```bash
cargo install lsdu
```

--- 

## Usage

### Basic listing
```bash
lsdu
lsdu -a
lsdu ~/Downloads
lsdu --bytes
lsdu --max-depth 1
```

### Sorting
```bash
lsdu --sort name
lsdu --sort size
lsdu --sort time
lsdu --sort ext
lsdu --sort size --reverse
```

### Git integration
```bash
lsdu --git
```

### Tree view
```bash
lsdu --tree
lsdu --tree --level 3
lsdu --tree --git --sort size --reverse
```

### Grid view
```bash
lsdu --grid
lsdu --grid --columns 4
```

### Filtering
```bash
lsdu --filter "*.rs"
lsdu --filter "*.rs" --filter "*.toml"
lsdu --min-size 10M
lsdu --max-size 200K
lsdu --only-dirs
lsdu --only-files --filter "*.log"
```

### Size suffixes supported:
B, K, M, G, T, P, E (1024 base)
Examples: 10K, 50M, 2G, 1T

### Interactive mode (fuzzy filtering + preview pane)
```bash
lsdu --interactive
lsdu -a --interactive
lsdu --interactive --filter "*.rs"
```
Select one or more entries and lsdu prints the selected paths to stdout.

### Preview (standalone)
```bash
lsdu --preview ./somefile.txt
lsdu --preview ./somedir
```

---

## Debian packaging

### Create a .deb locally:
```bash
cargo install cargo-deb
cargo deb
sudo dpkg -i target/debian/lsdu_*.deb
```

--- 

## License

### MIT License © Hugo
